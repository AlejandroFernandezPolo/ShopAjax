<script src="<?php echo e(url('assets/vendor/bootstrap/js/bootstrap.bundle.min.js')); ?>"></script>
      <script src="<?php echo e(url('assets/vendor/glightbox/js/glightbox.min.js')); ?>"></script>
      <script src="<?php echo e(url('assets/vendor/nouislider/nouislider.min.js')); ?>"></script>
      <script src="<?php echo e(url('assets/vendor/swiper/swiper-bundle.min.js')); ?>"></script>
      <script src="<?php echo e(url('assets/vendor/choices.js/public/assets/scripts/choices.min.js')); ?>"></script>
      <!-- FontAwesome CSS - loading as last, so it doesn't block rendering-->
      <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.7.1/css/all.css" integrity="sha384-fnmOCqbTlWIlj8LyTjo7mOUStjsKC4pOpQbqyi7RrhN7udi9RwhKkMHpvLbHG9Sr" crossorigin="anonymous">
<?php /**PATH /var/www/html/laraveles/shopApp/resources/views/assets/js.blade.php ENDPATH**/ ?>